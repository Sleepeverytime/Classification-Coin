# Coin > 2024-04-07 9:17pm
https://universe.roboflow.com/school-eawcy/coin-euzrf

Provided by a Roboflow user
License: CC BY 4.0

